# Opération Planète — Android

Application de jeu de stratégie fictif construite avec Kotlin et Jetpack Compose.

## Fonctionnalités
- Choix stratégiques avec effets sur les statistiques
- Tableau de bord : technologie, alliances, réputation, énergie et confiance
- Missions et historique des décisions
- Sauvegarde automatique locale via DataStore
- Réinitialisation de la partie

## Ouvrir et lancer
1. Installez Android Studio (version récente).
2. Décompressez le projet.
3. Dans Android Studio, choisissez **Open** et sélectionnez le dossier `OperationPlaneteAndroid`.
4. Laissez Gradle synchroniser les dépendances.
5. Lancez l'application sur un téléphone Android connecté en USB avec le débogage USB activé, ou sur un émulateur.

## Créer un APK
Dans Android Studio : **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
L'APK de débogage est généralement généré dans `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- Les chiffres et événements sont ceux d'une simulation de jeu, pas des données du monde réel.
- La sauvegarde est locale à l'appareil. Cette version ne synchronise pas les données entre plusieurs téléphones.
- Ce dossier est un projet source Android Studio, pas un APK précompilé.
