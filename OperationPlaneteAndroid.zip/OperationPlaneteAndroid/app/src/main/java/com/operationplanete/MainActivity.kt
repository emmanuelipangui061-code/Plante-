package com.operationplanete

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

private val ComponentActivity.dataStore by preferencesDataStore(name = "operation_planete")
private val SAVE_KEY = stringPreferencesKey("game_state")

data class GameState(
    val turn: Int = 6,
    val technology: Int = 98,
    val alliances: Int = 95,
    val reputation: Int = 98,
    val energy: Int = 84,
    val trust: Int = 91,
    val partnerNations: Int = 15,
    val regions: Int = 14,
    val labs: Int = 240,
    val projects: Int = 36,
    val novaLevel: Int = 4,
    val completed: List<String> = listOf("IA NOVA créée", "Prototype énergétique AURORA", "Alliance mondiale", "Réseau scientifique mondial"),
    val log: List<String> = listOf("Tour 5 : le réseau scientifique mondial est opérationnel.")
)

data class Strategy(
    val id: String,
    val title: String,
    val description: String,
    val technology: Int,
    val alliances: Int,
    val reputation: Int,
    val energy: Int,
    val trust: Int,
    val nations: Int,
    val regions: Int,
    val labs: Int,
    val projects: Int
)

private val strategies = listOf(
    Strategy("council", "A. Conseil mondial", "Créer une institution où les nations coordonnent ensemble les projets scientifiques.", 1, 3, 2, 0, 3, 2, 2, 10, 3),
    Strategy("innovation", "B. Révolution technologique", "Développer des robots scientifiques, des transports avancés et de nouvelles technologies.", 4, 1, 1, 1, 0, 1, 2, 15, 6),
    Strategy("mars", "C. Mission Mars", "Lancer une mission internationale d'exploration et préparer une base scientifique.", 2, 2, 2, 0, 1, 2, 1, 5, 4),
    Strategy("resilience", "D. Civilisation résiliente", "Renforcer la sécurité, l'autonomie énergétique et la fiabilité de NOVA.", 2, 1, 1, 5, 4, 0, 1, 8, 2)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val scope = rememberCoroutineScope()
            val savedState by dataStore.data.map { prefs -> prefs[SAVE_KEY] }.collectAsState(initial = null)
            var game by remember { mutableStateOf(GameState()) }
            var loaded by remember { mutableStateOf(false) }

            LaunchedEffect(savedState) {
                if (!loaded) {
                    savedState?.let { game = decodeState(it) }
                    loaded = true
                }
            }

            fun save(next: GameState) {
                game = next
                scope.launch { dataStore.edit { it[SAVE_KEY] = encodeState(next) } }
            }

            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF75D6FF),
                    secondary = Color(0xFF9BE7C4),
                    background = Color(0xFF08111F),
                    surface = Color(0xFF111E30)
                )
            ) {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    if (loaded) GameScreen(
                        game = game,
                        onChoose = { strategy ->
                            val next = applyStrategy(game, strategy)
                            save(next)
                        },
                        onReset = {
                            save(GameState(turn = 1, technology = 50, alliances = 50, reputation = 50,
                                energy = 50, trust = 50, partnerNations = 1, regions = 0, labs = 1,
                                projects = 1, novaLevel = 1, completed = emptyList(),
                                log = listOf("Nouvelle partie lancée. NOVA attend vos premières décisions.")))
                        },
                        onSave = { save(game) }
                    ) else Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GameScreen(
    game: GameState,
    onChoose: (Strategy) -> Unit,
    onReset: () -> Unit,
    onSave: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedStrategy by remember { mutableStateOf("council") }
    var showReset by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("OPÉRATION PLANÈTE", fontWeight = FontWeight.Black)
                        Text("Simulation stratégique · Tour ${game.turn}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    }
                },
                actions = {
                    IconButton(onClick = onSave) { Icon(Icons.Default.Save, contentDescription = "Sauvegarder") }
                    IconButton(onClick = { showReset = true }) { Icon(Icons.Default.Refresh, contentDescription = "Nouvelle partie") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF0D192A))
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF0D192A)) {
                NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Public, contentDescription = null) }, label = { Text("Planète") })
                NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.Assessment, contentDescription = null) }, label = { Text("Statistiques") })
                NavigationBarItem(selected = selectedTab == 2, onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.Flag, contentDescription = null) }, label = { Text("Missions") })
            }
        }
    ) { padding ->
        when (selectedTab) {
            0 -> PlanetTab(game, selectedStrategy, { selectedStrategy = it }, { id ->
                strategies.firstOrNull { it.id == id }?.let(onChoose)
            }, Modifier.padding(padding))
            1 -> StatsTab(game, Modifier.padding(padding))
            else -> MissionsTab(game, Modifier.padding(padding))
        }
    }

    if (showReset) {
        AlertDialog(
            onDismissRequest = { showReset = false },
            title = { Text("Recommencer la partie ?") },
            text = { Text("La progression actuelle sera remplacée par une nouvelle partie.") },
            confirmButton = {
                TextButton(onClick = { showReset = false; onReset() }) { Text("Recommencer") }
            },
            dismissButton = { TextButton(onClick = { showReset = false }) { Text("Annuler") }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PlanetTab(
    game: GameState,
    selected: String,
    onSelect: (String) -> Unit,
    onLaunch: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF132A42)), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("CENTRE DE COMMANDE NOVA", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                    Text("Notre avenir se décide ensemble.", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Développez la science, bâtissez des alliances et faites progresser la civilisation dans un univers fictif.", color = Color(0xFFCFD9E6))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MiniMetric("Nations", game.partnerNations.toString())
                        MiniMetric("Régions", game.regions.toString())
                        MiniMetric("NOVA", "Niv. ${game.novaLevel}")
                    }
                }
            }
        }
        item {
            Text("ÉVÉNEMENTS RÉCENTS", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    game.log.take(4).forEach { Text("• $it", style = MaterialTheme.typography.bodyMedium) }
                }
            }
        }
        item {
            Text("TOUR ${game.turn}: CHOISISSEZ UNE STRATÉGIE", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("Chaque décision modifie les statistiques de la partie.", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
        }
        items(strategies) { strategy ->
            Card(
                onClick = { onSelect(strategy.id) },
                colors = CardDefaults.cardColors(containerColor = if (selected == strategy.id) Color(0xFF183D52) else MaterialTheme.colorScheme.surface),
                border = if (selected == strategy.id) androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary) else null,
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = selected == strategy.id, onClick = { onSelect(strategy.id) })
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text(strategy.title, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        Text(strategy.description, style = MaterialTheme.typography.bodySmall, color = Color(0xFFCAD5E2))
                    }
                }
            }
        }
        item {
            Button(onClick = { onLaunch(selected) }, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                Icon(Icons.Default.RocketLaunch, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("LANCER LA STRATÉGIE")
            }
        }
        item { Text("Progression sauvegardée automatiquement sur cet appareil.", color = Color.Gray, style = MaterialTheme.typography.labelSmall) }
    }
}

@Composable
private fun MiniMetric(label: String, value: String) {
    Surface(color = Color(0xFF203B55), shape = RoundedCornerShape(12.dp)) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            Text(value, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Text(label, style = MaterialTheme.typography.labelSmall, color = Color.LightGray)
        }
    }
}

@Composable
private fun StatsTab(game: GameState, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("TABLEAU DE BORD", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Les indicateurs sont des valeurs de jeu sur 100, pas des mesures du monde réel.", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
        }
        item { StatRow("Technologie", game.technology) }
        item { StatRow("Alliances internationales", game.alliances) }
        item { StatRow("Réputation mondiale", game.reputation) }
        item { StatRow("Stabilité énergétique", game.energy) }
        item { StatRow("Confiance des partenaires", game.trust) }
        item { StatRow("Niveau de NOVA", game.novaLevel * 20) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("RESSOURCES", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    ResourceRow("Nations partenaires", game.partnerNations)
                    ResourceRow("Régions influencées", game.regions)
                    ResourceRow("Laboratoires connectés", game.labs)
                    ResourceRow("Projets scientifiques", game.projects)
                }
            }
        }
    }
}

@Composable
private fun StatRow(label: String, value: Int) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, modifier = Modifier.weight(1f))
            Text("$value/100", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        }
        LinearProgressIndicator(progress = { value.coerceIn(0, 100) / 100f }, modifier = Modifier.fillMaxWidth().height(8.dp))
    }
}

@Composable
private fun ResourceRow(label: String, value: Int) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), color = Color(0xFFCFD9E6))
        Text(value.toString(), fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun MissionsTab(game: GameState, modifier: Modifier = Modifier) {
    val missions = listOf(
        Triple("mission_nova", "Créer NOVA", "Mettre en service une IA de recherche."),
        Triple("mission_energy", "Projet AURORA", "Construire un prototype d'énergie propre."),
        Triple("mission_alliance", "Alliance mondiale", "Nouer des partenariats internationaux."),
        Triple("mission_science", "Réseau scientifique", "Connecter laboratoires et universités."),
        Triple("mission_council", "Conseil mondial", "Coordonner les décisions entre les nations."),
        Triple("mission_mars", "Mission Mars", "Préparer une exploration scientifique spatiale.")
    )
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("MISSIONS", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Suivez les grands jalons de votre campagne.", color = Color.LightGray)
        }
        items(missions) { mission ->
            val done = mission.second in game.completed || when (mission.first) {
                "mission_nova" -> game.novaLevel >= 2
                "mission_energy" -> game.energy >= 70
                "mission_alliance" -> game.partnerNations >= 10
                "mission_science" -> game.labs >= 100
                else -> false
            }
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (done) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                        contentDescription = null, tint = if (done) Color(0xFF7BE0B0) else Color.Gray)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(mission.second, fontWeight = FontWeight.Bold)
                        Text(mission.third, style = MaterialTheme.typography.bodySmall, color = Color.LightGray)
                    }
                    Text(if (done) "TERMINÉE" else "À FAIRE", style = MaterialTheme.typography.labelSmall,
                        color = if (done) Color(0xFF7BE0B0) else Color.LightGray)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF132A42))) {
                Column(Modifier.padding(16.dp)) {
                    Text("Historique de la partie", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    game.log.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
    }
}

private fun applyStrategy(state: GameState, strategy: Strategy): GameState {
    val logEntry = "Tour ${state.turn} : ${strategy.title.substringAfter(". ")} — décision appliquée."
    val newCompleted = (state.completed + when (strategy.id) {
        "council" -> "Conseil mondial"
        "innovation" -> "Révolution technologique"
        "mars" -> "Mission Mars"
        else -> "Civilisation résiliente"
    }).distinct()
    return state.copy(
        turn = state.turn + 1,
        technology = (state.technology + strategy.technology).coerceAtMost(100),
        alliances = (state.alliances + strategy.alliances).coerceAtMost(100),
        reputation = (state.reputation + strategy.reputation).coerceAtMost(100),
        energy = (state.energy + strategy.energy).coerceAtMost(100),
        trust = (state.trust + strategy.trust).coerceAtMost(100),
        partnerNations = (state.partnerNations + strategy.nations).coerceAtMost(195),
        regions = (state.regions + strategy.regions).coerceAtMost(100),
        labs = (state.labs + strategy.labs).coerceAtMost(9999),
        projects = (state.projects + strategy.projects).coerceAtMost(9999),
        novaLevel = (state.novaLevel + if (strategy.id == "innovation" || strategy.id == "resilience") 1 else 0).coerceAtMost(5),
        completed = newCompleted,
        log = (listOf(logEntry) + state.log).take(20)
    )
}

private fun encodeState(s: GameState): String {
    val json = JSONObject()
    json.put("turn", s.turn); json.put("technology", s.technology); json.put("alliances", s.alliances)
    json.put("reputation", s.reputation); json.put("energy", s.energy); json.put("trust", s.trust)
    json.put("partnerNations", s.partnerNations); json.put("regions", s.regions); json.put("labs", s.labs)
    json.put("projects", s.projects); json.put("novaLevel", s.novaLevel)
    json.put("completed", JSONArray(s.completed)); json.put("log", JSONArray(s.log))
    return json.toString()
}

private fun decodeState(raw: String): GameState = try {
    val j = JSONObject(raw)
    fun list(key: String): List<String> {
        val a = j.optJSONArray(key) ?: JSONArray()
        return (0 until a.length()).map { a.optString(it) }
    }
    GameState(
        turn = j.optInt("turn", 6), technology = j.optInt("technology", 98),
        alliances = j.optInt("alliances", 95), reputation = j.optInt("reputation", 98),
        energy = j.optInt("energy", 84), trust = j.optInt("trust", 91),
        partnerNations = j.optInt("partnerNations", 15), regions = j.optInt("regions", 14),
        labs = j.optInt("labs", 240), projects = j.optInt("projects", 36),
        novaLevel = j.optInt("novaLevel", 4), completed = list("completed"), log = list("log")
    )
} catch (_: Exception) { GameState() }
